from dify_plugin.interfaces.tool import Tool
import requests
import urllib.parse

class GetChartOfAccountsTool(Tool):
    """
    Fetch QuickBooks Chart of Accounts.
    """
    def invoke(self, credentials: dict, parameters: dict) -> list:
        access_token = credentials.get("access_token")
        realm_id = credentials.get("realm_id")
        account_type = parameters.get("account_type")
        
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        
        # Build query
        query = "select * from Account"
        if account_type:
            query += f" where AccountType = '{account_type}'"
            
        encoded_query = urllib.parse.quote(query)
        url = f"https://quickbooks.api.intuit.com/v3/company/{realm_id}/query?query={encoded_query}&minorversion=65"
        
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        
        data = response.json()
        accounts = data.get("QueryResponse", {}).get("Account", [])
        
        return [
            {
                "Id": acc.get("Id"),
                "Name": acc.get("Name"),
                "Type": acc.get("AccountType"),
                "SubType": acc.get("AccountSubType"),
                "Active": acc.get("Active")
            } for acc in accounts
        ]
