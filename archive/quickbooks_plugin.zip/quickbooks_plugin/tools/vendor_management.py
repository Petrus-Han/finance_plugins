from dify_plugin.interfaces.tool import Tool
import requests
import urllib.parse

class VendorManagementTool(Tool):
    """
    Search or Create Vendor in QuickBooks.
    """
    def invoke(self, credentials: dict, parameters: dict) -> dict:
        access_token = credentials.get("access_token")
        realm_id = credentials.get("realm_id")
        action = parameters.get("action")
        name = parameters.get("name")
        
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        
        if action == "search":
            query = f"select * from Vendor where DisplayName like '%{name.replace(\"'\", \"''\")}%'"
            encoded_query = urllib.parse.quote(query)
            url = f"https://quickbooks.api.intuit.com/v3/company/{realm_id}/query?query={encoded_query}&minorversion=65"
            
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            
            vendors = response.json().get("QueryResponse", {}).get("Vendor", [])
            return {"vendors": vendors}
            
        elif action == "create":
            url = f"https://quickbooks.api.intuit.com/v3/company/{realm_id}/vendor?minorversion=65"
            payload = {
                "DisplayName": name,
                "CompanyName": name
            }
            response = requests.post(url, headers=headers, json=payload)
            response.raise_for_status()
            return response.json().get("Vendor")
            
        return {"error": "Invalid action"}
        
