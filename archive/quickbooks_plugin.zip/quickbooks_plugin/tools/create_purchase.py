from dify_plugin.interfaces.tool import Tool
import requests

class CreatePurchaseTool(Tool):
    """
    Create a Purchase (Expense) in QuickBooks.
    """
    def invoke(self, credentials: dict, parameters: dict) -> dict:
        access_token = credentials.get("access_token")
        realm_id = credentials.get("realm_id")
        
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        
        # Mapping parameters to QBO Purchase Entity
        payload = {
            "AccountRef": {
                "value": parameters.get("bank_account_id")
            },
            "PaymentType": parameters.get("payment_type", "CreditCard"),
            "TxnDate": parameters.get("txn_date"),
            "PrivateNote": parameters.get("note"),
            "Line": [
                {
                    "Amount": abs(parameters.get("amount")),
                    "DetailType": "AccountBasedExpenseLineDetail",
                    "Description": parameters.get("description"),
                    "AccountBasedExpenseLineDetail": {
                        "AccountRef": {
                            "value": parameters.get("expense_account_id")
                        }
                    }
                }
            ]
        }
        
        if parameters.get("vendor_id"):
            payload["EntityRef"] = {
                "value": parameters.get("vendor_id"),
                "type": "Vendor"
            }

        url = f"https://quickbooks.api.intuit.com/v3/company/{realm_id}/purchase?minorversion=65"
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        return response.json().get("Purchase")
