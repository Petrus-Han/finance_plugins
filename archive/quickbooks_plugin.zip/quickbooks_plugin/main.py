from dify_plugin import Plugin
from tools.get_chart_of_accounts import GetChartOfAccountsTool
from tools.vendor_management import VendorManagementTool
from tools.create_purchase import CreatePurchaseTool
from tools.create_deposit import CreateDepositTool

plugin = Plugin()

# Register Tools
plugin.register_tool('get_chart_of_accounts', GetChartOfAccountsTool)
plugin.register_tool('vendor_management', VendorManagementTool)
plugin.register_tool('create_purchase', CreatePurchaseTool)
plugin.register_tool('create_deposit', CreateDepositTool)

if __name__ == '__main__':
    plugin.run()
